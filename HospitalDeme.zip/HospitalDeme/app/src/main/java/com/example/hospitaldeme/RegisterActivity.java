package com.example.hospitaldeme;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    EditText edUsername,edEmail,edPassword, edConfromPw;
    Button regBtn;
    TextView tv1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        edUsername = findViewById(R.id.editTextAppFullName);
        edEmail = findViewById(R.id.editTextAppAddress);
        edPassword = findViewById(R.id.editTextAppNumber);
        edConfromPw = findViewById(R.id.editTextAppFee);
        regBtn = findViewById(R.id.ButtonRegister);
        tv1 = findViewById(R.id.textViewForExitingUsers);
        Database db = new Database(getApplicationContext(), "HealthCare",null,1);

        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });

        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = edUsername.getText().toString();
                String email = edEmail.getText().toString();
                String password = edPassword.getText().toString();
                String confpassword = edConfromPw.getText().toString();

                if (username.length() ==0 || email.length() ==0 || password.length() == 0 || confpassword.length() == 0){
                    Toast.makeText(getApplicationContext(), "Please fill the Details",Toast.LENGTH_SHORT).show();
                }
               else {
                   if (password.compareTo(confpassword)==0){
                      if (isValid(password)){
                          db.register(username,email,password);
                          Toast.makeText(getApplicationContext(),"Record inserted sucessfuly",Toast.LENGTH_SHORT).show();
                          startActivity(new Intent(RegisterActivity.this, LoginActivity.class));

                      }else {
                          Toast.makeText(getApplicationContext(),"Password must contain at least 8 characters, having letters,digit and symbol,",Toast.LENGTH_SHORT).show();
                      }
                   }
                   else {
                       Toast.makeText(getApplicationContext(),"Password didn't match",Toast.LENGTH_SHORT).show();
                   }
                }
            }
        });


    }
    public static boolean isValid(String password){
        int t1=0,t2=0,t3=0,t4=0;
        if (password.length() < 8){
            return false;
        }
        else {
            for (int p=0;p<password.length();p++){
                if (Character.isLetter(password.charAt(p))){
                    t1=1;
                }
            }
            for (int r=0;r<password.length();r++){
                if (Character.isDigit(password.charAt(r))){
                    t2=1;
                }
            }
            for (int s=0;s<password.length();s++){
               char c = password.charAt(s);
               if (c>=33 && c<=46 || c == 64){
                   t3=1;
               }
            }
            if (t1==1 && t2==1 && t3 == 1){
                return true;
            }
            return false;
        }
    }
}