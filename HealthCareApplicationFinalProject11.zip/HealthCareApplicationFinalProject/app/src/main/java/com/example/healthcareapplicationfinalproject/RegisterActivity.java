package com.example.healthcareapplicationfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText edUsername, edEmail,edPassword, edConPassword;
    Button regBtn;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        edUsername = findViewById(R.id.editTextRegUsername);
        edEmail = findViewById(R.id.editTextRegEmail);
        edPassword = findViewById(R.id.editTextRegPassword);
        edConPassword = findViewById(R.id.editTextRegConPassword);
        regBtn = findViewById(R.id.ButtonForRegister);
        tv = findViewById(R.id.textforLogin);
        Database db = new Database(getApplicationContext(), "HealthCareDatabase",null,1);


        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });

        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = edUsername.getText().toString();
                String email = edEmail.getText().toString();
                String password = edPassword.getText().toString();
                String conPassword = edConPassword.getText().toString();

                if (username.length() == 0 || email.length() == 0 || password.length() == 0 || conPassword.length() == 0) {
                    Toast.makeText(getApplicationContext(), "Please fill the details", Toast.LENGTH_SHORT).show();
                } else {
                    if (password.compareTo(conPassword)==0){
                        String em = edEmail.getText().toString().trim();
                        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                        if (em.matches(emailPattern)) {
                            if (isValid(password)){
                                db.register(username,email,password);
                                Toast.makeText(getApplicationContext(),"Record insert Sucessfully",Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(RegisterActivity.this,LoginActivity.class));

                            }else {
                                Toast.makeText(getApplicationContext(),"Password must contain at least 8 characters, having letters,digit and symbol",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"Invalid email address", Toast.LENGTH_SHORT).show();
                        }

                    }
                    else {
                        Toast.makeText(getApplicationContext(),"Password not match",Toast.LENGTH_SHORT).show();

                    }


                }
            }
        });

    }
    public static boolean isValid(String password){
        int t1=0,t2=0,t3=0,t4=0;
        if (password.length() < 8){
            return false;
        }
        else {
            for (int p=0;p<password.length();p++){
                if (Character.isLetter(password.charAt(p))){
                    t1=1;
                }
            }
            for (int r=0;r<password.length();r++){
                if (Character.isDigit(password.charAt(r))){
                    t2=1;
                }
            }
            for (int s=0;s<password.length();s++){
                char c = password.charAt(s);
                if (c>=33 && c<=46 || c == 64){
                    t3=1;
                }
            }
            if (t1==1 && t2==1 && t3 == 1){
                return true;
            }
            return false;
        }
    }
}