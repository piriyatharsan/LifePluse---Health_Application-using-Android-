package com.example.healthcareapplicationfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    EditText edusername, edpassword;
    Button logBtn;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edusername = findViewById(R.id.editTextRegUsername);
        edpassword = findViewById(R.id.editTextRegConPassword);
        logBtn = findViewById(R.id.ButtonForRegister);
        tv = findViewById(R.id.textforLogin);


        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });
        logBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = edusername.getText().toString();
                String password = edpassword.getText().toString();
                Database db = new Database(getApplicationContext(), "HealthCareDatabase",null,1);

                if(username.length()==0 || password.length()==0){
                    Toast.makeText(getApplicationContext(),"Please fill the Details",Toast.LENGTH_SHORT).show();
                }
                else{
                    if (db.Login(username,password)==1){
                        Toast.makeText(getApplicationContext(),"Login Sucessfull",Toast.LENGTH_SHORT).show();
                        SharedPreferences sharedPreferences = getSharedPreferences("share_Prefs", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("username",username);     // to save our data key and value
                        editor.apply();
                        startActivity(new Intent(LoginActivity.this,DashboardActivity.class));
                    }else {
                        Toast.makeText(getApplicationContext(),"Invaild username and password",Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });
    }
}