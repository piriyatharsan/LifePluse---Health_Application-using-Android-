package com.example.healthcareapplicationfinalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.Manifest;

public class DashboardActivity extends AppCompatActivity {

    Button callingBtn;
    static int PERMISSION_CODE = 100;
    private SensorPage sensorPage;          // For Sensor

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        sensorPage = new SensorPage(this);
        sensorPage.registerSensor();


        callingBtn =findViewById(R.id.calling);

        if(ContextCompat.checkSelfPermission(DashboardActivity.this,Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(DashboardActivity.this,new String[]{Manifest.permission.CALL_PHONE},PERMISSION_CODE);
        }
        callingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = "110";
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:"+number));
                startActivity(intent);

            }
        });


        CardView findDocter = findViewById(R.id.dasFindDocter);
        findDocter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DashboardActivity.this,FindDocterActivity.class));

            }
        });

        CardView bloodDonation = findViewById(R.id.bloodDonation);
        bloodDonation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DashboardActivity.this,BloodDonation.class));

            }
        });

        CardView LabTest = findViewById(R.id.LabTestPackege);
        LabTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DashboardActivity.this,LabTestActivity.class));

            }
        });


    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        sensorPage.unregisterSensor();
    }
}